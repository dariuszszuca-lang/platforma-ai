/**
 * The Lead Queue Sheet, with the 2 hour rule.
 * AI-Team, https://ai-team.pl/en
 *
 * Paste this whole file into Extensions > Apps Script, save, then run
 * installTriggers once and accept the permission screen.
 *
 * Nothing here is configured in code. Team, timeout and owner email all come
 * from the Team and Settings tabs of the spreadsheet.
 */

/* ------------------------------------------------------------------ config */

var SHEET_LEADS = 'Leads';
var SHEET_TEAM = 'Team';
var SHEET_SETTINGS = 'Settings';
var SHEET_AUDIT = 'Audit';

/* Leads tab, 1 based column numbers. Change these if you move columns. */
var COL_TIMESTAMP = 1;
var COL_NAME = 2;
var COL_PHONE = 3;
var COL_EMAIL = 4;
var COL_SOURCE = 5;
var COL_ASSIGNED_TO = 6;
var COL_ASSIGNED_AT = 7;
var COL_STATUS = 8;
var COL_CONTACTED_AT = 9;
var COL_OVERDUE = 10;
var COL_NOTES = 11;

/* Team tab, 1 based column numbers. */
var TEAM_COL_NAME = 1;
var TEAM_COL_EMAIL = 2;
var TEAM_COL_AWAY = 3;
var TEAM_COL_ORDER = 4;

/* Audit tab, 1 based column numbers. */
var AUDIT_COL_TIMESTAMP = 1;
var AUDIT_COL_LEAD = 2;
var AUDIT_COL_FROM = 3;
var AUDIT_COL_TO = 4;
var AUDIT_COL_REASON = 5;

var STATUS_NEW = 'New';
var FIRST_DATA_ROW = 2;

var REASON_ASSIGNED = 'assigned';
var REASON_TIMEOUT = 'timeout';
var REASON_ESCALATED = 'full circle, owner notified';

var DEFAULT_TIMEOUT_HOURS = 2;
var MINUTES_ASSIGN = 5;
var MINUTES_TIMEOUT = 15;

/* ------------------------------------------------------------------- menu */

/**
 * Adds the Lead Queue menu every time somebody opens the file.
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Lead Queue')
    .addItem('Assign now', 'assignNewLeads')
    .addItem('Check timeouts', 'checkTimeouts')
    .addSeparator()
    .addItem('Install triggers', 'installTriggers')
    .addToUi();
}

/* ------------------------------------------------------------- read config */

/**
 * Reads the Settings tab into a plain object.
 * Column A holds the key, column B holds the value.
 */
function readSettings_() {
  var sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_SETTINGS);
  var out = {
    timeoutHours: DEFAULT_TIMEOUT_HOURS,
    notifyByEmail: true,
    ownerEmail: ''
  };
  if (!sheet) {
    return out;
  }
  var last = sheet.getLastRow();
  if (last < FIRST_DATA_ROW) {
    return out;
  }
  var rows = sheet.getRange(FIRST_DATA_ROW, 1, last - FIRST_DATA_ROW + 1, 2).getValues();
  for (var i = 0; i < rows.length; i++) {
    var key = String(rows[i][0]).trim().toLowerCase();
    var value = rows[i][1];
    if (key === 'timeout_hours') {
      var hours = Number(value);
      if (!isNaN(hours) && hours > 0) {
        out.timeoutHours = hours;
      }
    } else if (key === 'notify_by_email') {
      out.notifyByEmail = String(value).trim().toUpperCase() === 'Y';
    } else if (key === 'owner_email') {
      out.ownerEmail = String(value).trim();
    }
  }
  return out;
}

/**
 * Reads the Team tab, sorted by the Order column.
 * Returns a list of { name, email, away, order }.
 */
function readTeam_() {
  var sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_TEAM);
  var team = [];
  if (!sheet) {
    return team;
  }
  var last = sheet.getLastRow();
  if (last < FIRST_DATA_ROW) {
    return team;
  }
  var rows = sheet.getRange(FIRST_DATA_ROW, 1, last - FIRST_DATA_ROW + 1, TEAM_COL_ORDER).getValues();
  for (var i = 0; i < rows.length; i++) {
    var name = String(rows[i][TEAM_COL_NAME - 1]).trim();
    if (!name) {
      continue;
    }
    var order = Number(rows[i][TEAM_COL_ORDER - 1]);
    team.push({
      name: name,
      email: String(rows[i][TEAM_COL_EMAIL - 1]).trim(),
      away: String(rows[i][TEAM_COL_AWAY - 1]).trim().toUpperCase() === 'Y',
      order: isNaN(order) ? i + 1 : order
    });
  }
  team.sort(function (a, b) {
    return a.order - b.order;
  });
  return team;
}

/**
 * True when at least one person on the team is available.
 */
function countActive_(team) {
  var n = 0;
  for (var i = 0; i < team.length; i++) {
    if (!team[i].away) {
      n++;
    }
  }
  return n;
}

/* ------------------------------------------------------------- round robin */

/**
 * Picks the next available person after the one named in lastName.
 * Away people are skipped. An empty or unknown lastName starts at the top.
 * Returns null when nobody is available.
 */
function nextInQueue_(team, lastName) {
  if (countActive_(team) === 0) {
    return null;
  }
  var startAt = 0;
  if (lastName) {
    for (var i = 0; i < team.length; i++) {
      if (team[i].name === lastName) {
        startAt = i + 1;
        break;
      }
    }
  }
  for (var step = 0; step < team.length; step++) {
    var candidate = team[(startAt + step) % team.length];
    if (!candidate.away) {
      return candidate;
    }
  }
  return null;
}

/**
 * Finds the person named in the last filled Assigned to cell, scanning up.
 * Returns an empty string when no lead has ever been assigned.
 */
function lastAssignedName_(values) {
  for (var i = values.length - 1; i >= 0; i--) {
    var name = String(values[i][COL_ASSIGNED_TO - 1]).trim();
    if (name) {
      return name;
    }
  }
  return '';
}

/* ------------------------------------------------------------------ audit */

/**
 * Builds a stable label for a lead, used in the Audit tab.
 */
function leadKey_(row, rowNumber) {
  var name = String(row[COL_NAME - 1]).trim();
  if (name) {
    return name;
  }
  var email = String(row[COL_EMAIL - 1]).trim();
  if (email) {
    return email;
  }
  return 'Row ' + rowNumber;
}

/**
 * Appends one line to the Audit tab.
 */
function writeAudit_(lead, from, to, reason) {
  var sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_AUDIT);
  if (!sheet) {
    return;
  }
  var line = [];
  line[AUDIT_COL_TIMESTAMP - 1] = new Date();
  line[AUDIT_COL_LEAD - 1] = lead;
  line[AUDIT_COL_FROM - 1] = from;
  line[AUDIT_COL_TO - 1] = to;
  line[AUDIT_COL_REASON - 1] = reason;
  sheet.appendRow(line);
}

/**
 * Counts how many times a lead already appears in the Audit tab
 * with a reason that starts with the given prefix.
 */
function countAudit_(lead, reasonPrefix) {
  var sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_AUDIT);
  if (!sheet) {
    return 0;
  }
  var last = sheet.getLastRow();
  if (last < FIRST_DATA_ROW) {
    return 0;
  }
  var rows = sheet.getRange(FIRST_DATA_ROW, 1, last - FIRST_DATA_ROW + 1, AUDIT_COL_REASON).getValues();
  var n = 0;
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][AUDIT_COL_LEAD - 1]).trim() !== String(lead).trim()) {
      continue;
    }
    if (String(rows[i][AUDIT_COL_REASON - 1]).indexOf(reasonPrefix) === 0) {
      n++;
    }
  }
  return n;
}

/* ------------------------------------------------------------------- mail */

/**
 * Sends one plain text email. Silent when notify_by_email is not Y
 * or when the address is missing.
 */
function sendMail_(config, to, subject, body) {
  if (!config.notifyByEmail) {
    return;
  }
  if (!to || to.indexOf('@') < 0) {
    return;
  }
  MailApp.sendEmail(to, subject, body);
}

/**
 * Writes the body of a lead email.
 */
function leadEmailBody_(row, rowNumber, config, note) {
  var lines = [];
  lines.push(note);
  lines.push('');
  lines.push('Name: ' + String(row[COL_NAME - 1]));
  lines.push('Phone: ' + String(row[COL_PHONE - 1]));
  lines.push('Email: ' + String(row[COL_EMAIL - 1]));
  lines.push('Source: ' + String(row[COL_SOURCE - 1]));
  lines.push('Notes: ' + String(row[COL_NOTES - 1]));
  lines.push('');
  lines.push('You have ' + config.timeoutHours + ' hours to make contact.');
  lines.push('Set Status to Contacted and fill Contacted at when you do.');
  lines.push('Row ' + rowNumber + ' in the Leads tab.');
  lines.push(SpreadsheetApp.getActive().getUrl());
  return lines.join('\n');
}

/* ------------------------------------------------------------ assign leads */

/**
 * Gives every unassigned New lead to the next person in the queue.
 * Runs round robin over the Team tab and skips anybody marked Away.
 */
function assignNewLeads() {
  var sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_LEADS);
  if (!sheet) {
    return 0;
  }
  var last = sheet.getLastRow();
  if (last < FIRST_DATA_ROW) {
    return 0;
  }

  var config = readSettings_();
  var team = readTeam_();
  if (countActive_(team) === 0) {
    return 0;
  }

  var width = COL_NOTES;
  var range = sheet.getRange(FIRST_DATA_ROW, 1, last - FIRST_DATA_ROW + 1, width);
  var values = range.getValues();
  var lastName = lastAssignedName_(values);
  var assigned = 0;

  for (var i = 0; i < values.length; i++) {
    var row = values[i];
    var rowNumber = FIRST_DATA_ROW + i;
    var status = String(row[COL_STATUS - 1]).trim();
    var owner = String(row[COL_ASSIGNED_TO - 1]).trim();
    var name = String(row[COL_NAME - 1]).trim();
    var email = String(row[COL_EMAIL - 1]).trim();

    if (status !== STATUS_NEW || owner) {
      continue;
    }
    if (!name && !email) {
      continue;
    }

    var person = nextInQueue_(team, lastName);
    if (!person) {
      break;
    }

    var now = new Date();
    if (!row[COL_TIMESTAMP - 1]) {
      row[COL_TIMESTAMP - 1] = now;
    }
    row[COL_ASSIGNED_TO - 1] = person.name;
    row[COL_ASSIGNED_AT - 1] = now;
    values[i] = row;

    lastName = person.name;
    assigned++;

    writeAudit_(leadKey_(row, rowNumber), '', person.name, REASON_ASSIGNED);
    sendMail_(
      config,
      person.email,
      'New lead for you: ' + leadKey_(row, rowNumber),
      leadEmailBody_(row, rowNumber, config, 'This lead is yours.')
    );
  }

  if (assigned > 0) {
    range.setValues(values);
  }
  return assigned;
}

/* ---------------------------------------------------------- check timeouts */

/**
 * Passes on every New lead that has waited longer than timeout_hours.
 * After the lead has gone round every available person once, the owner
 * gets one email and the lead stops moving.
 */
function checkTimeouts() {
  var sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_LEADS);
  if (!sheet) {
    return 0;
  }
  var last = sheet.getLastRow();
  if (last < FIRST_DATA_ROW) {
    return 0;
  }

  var config = readSettings_();
  var team = readTeam_();
  var activeCount = countActive_(team);
  if (activeCount === 0) {
    return 0;
  }

  var width = COL_NOTES;
  var range = sheet.getRange(FIRST_DATA_ROW, 1, last - FIRST_DATA_ROW + 1, width);
  var values = range.getValues();
  var limitMs = config.timeoutHours * 60 * 60 * 1000;
  var now = new Date();
  var moved = 0;

  for (var i = 0; i < values.length; i++) {
    var row = values[i];
    var rowNumber = FIRST_DATA_ROW + i;
    var status = String(row[COL_STATUS - 1]).trim();
    var owner = String(row[COL_ASSIGNED_TO - 1]).trim();
    var assignedAt = row[COL_ASSIGNED_AT - 1];

    if (status !== STATUS_NEW || !owner || !assignedAt) {
      continue;
    }
    if (!(assignedAt instanceof Date)) {
      assignedAt = new Date(assignedAt);
    }
    if (isNaN(assignedAt.getTime())) {
      continue;
    }
    if (now.getTime() - assignedAt.getTime() <= limitMs) {
      continue;
    }

    var key = leadKey_(row, rowNumber);
    var hops = countAudit_(key, REASON_TIMEOUT);

    if (hops >= activeCount) {
      if (countAudit_(key, REASON_ESCALATED) === 0) {
        writeAudit_(key, owner, config.ownerEmail, REASON_ESCALATED);
        sendMail_(
          config,
          config.ownerEmail,
          'Nobody picked up this lead: ' + key,
          leadEmailBody_(
            row,
            rowNumber,
            config,
            'This lead went round the whole team and is still on New. It is parked with ' + owner + '.'
          )
        );
      }
      continue;
    }

    var person = nextInQueue_(team, owner);
    if (!person || person.name === owner) {
      continue;
    }

    row[COL_ASSIGNED_TO - 1] = person.name;
    row[COL_ASSIGNED_AT - 1] = now;
    values[i] = row;
    moved++;

    writeAudit_(key, owner, person.name, REASON_TIMEOUT + ' after ' + config.timeoutHours + ' h');
    sendMail_(
      config,
      person.email,
      'Passed to you, still not contacted: ' + key,
      leadEmailBody_(row, rowNumber, config, 'This lead waited too long with ' + owner + '. It is yours now.')
    );
  }

  if (moved > 0) {
    range.setValues(values);
  }
  return moved;
}

/* --------------------------------------------------------------- triggers */

/**
 * Sets the two time triggers and removes any older copies of them,
 * so running this twice does not double the schedule.
 */
function installTriggers() {
  var handlers = ['assignNewLeads', 'checkTimeouts'];
  var existing = ScriptApp.getProjectTriggers();
  for (var i = 0; i < existing.length; i++) {
    if (handlers.indexOf(existing[i].getHandlerFunction()) >= 0) {
      ScriptApp.deleteTrigger(existing[i]);
    }
  }

  ScriptApp.newTrigger('assignNewLeads').timeBased().everyMinutes(MINUTES_ASSIGN).create();
  ScriptApp.newTrigger('checkTimeouts').timeBased().everyMinutes(MINUTES_TIMEOUT).create();

  SpreadsheetApp.getActive().toast(
    'Triggers are on. Assign every ' + MINUTES_ASSIGN + ' min, timeout check every ' + MINUTES_TIMEOUT + ' min.',
    'Lead Queue',
    8
  );
}
